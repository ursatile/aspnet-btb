namespace Rockaway.WebApp.Services;

public class ServerStatus {
	public string Assembly { get; set; } = String.Empty;
	public string Modified { get; set; } = String.Empty;
	public string Hostname { get; set; } = String.Empty;
	public string DateTime { get; set; } = String.Empty;
}