global using System.ComponentModel.DataAnnotations;
global using System.Globalization;
global using System.Text;
global using Microsoft.AspNetCore.Mvc;
global using Microsoft.AspNetCore.Mvc.RazorPages;
global using Microsoft.EntityFrameworkCore;
global using NodaTime;