namespace Rockaway.WebApp.Pages;

public class ContactModel : PageModel {

	public void OnGet() {
	}
}